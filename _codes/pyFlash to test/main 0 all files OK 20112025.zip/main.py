# main.py -- put your code here!
from pyb import Pin, ADC, LED, UART, delay
import pyb
import select


# --- Setup ---
red_led = LED(1)  # Red LED
green_led = LED(2)  # Green LED
yellow_led = LED(3)  # Yellow LED
blue_led = LED(4)  # Blue LED
LEDs = [red_led,green_led,yellow_led,blue_led]






#generic IOs setup
X1=pyb.Pin(pyb.Pin.board.X1, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
X2=pyb.Pin(pyb.Pin.board.X2, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
X3=pyb.Pin(pyb.Pin.board.X3, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
X4=pyb.Pin(pyb.Pin.board.X4, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
X5=pyb.Pin(pyb.Pin.board.X5, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
X6=pyb.Pin(pyb.Pin.board.X6, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
X7=pyb.Pin(pyb.Pin.board.X7, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
X8=pyb.Pin(pyb.Pin.board.X8, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
X9=pyb.Pin(pyb.Pin.board.X9, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
X10=pyb.Pin(pyb.Pin.board.X10, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
X11=pyb.Pin(pyb.Pin.board.X11, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
X12=pyb.Pin(pyb.Pin.board.X12, pyb.Pin.IN, pyb.Pin.PULL_DOWN)

Y1=pyb.Pin(pyb.Pin.board.Y1, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
Y2=pyb.Pin(pyb.Pin.board.Y2, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
Y3=pyb.Pin(pyb.Pin.board.Y3, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
Y4=pyb.Pin(pyb.Pin.board.Y4, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
Y5=pyb.Pin(pyb.Pin.board.Y5, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
Y6=pyb.Pin(pyb.Pin.board.Y6, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
Y7=pyb.Pin(pyb.Pin.board.Y7, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
Y8=pyb.Pin(pyb.Pin.board.Y8, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
Y9=pyb.Pin(pyb.Pin.board.Y9, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
Y10=pyb.Pin(pyb.Pin.board.Y10, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
Y11=pyb.Pin(pyb.Pin.board.Y11, pyb.Pin.IN, pyb.Pin.PULL_DOWN)
Y12=pyb.Pin(pyb.Pin.board.Y12, pyb.Pin.IN, pyb.Pin.PULL_DOWN)


IOs=[X1,X2,X3,X4,X5,X6,X7,X8,X9,X10,X11,X12,
        Y1,Y2,Y3,Y4,Y5,Y6,Y7,Y8,Y9,Y10,Y11,Y12]


"""
with open('out.txt', 'w') as f:
    print('start1...', file=f)
with open('out.txt', 'a') as f:
    print('start2...', file=f)
"""


#main cycle
red_led.off()
yellow_led.off()
blue_led.off()
green_led.off()



#IOs setup & cycle
for m in range(23):
    #reassign pin as output
    IOs[m].init(Pin.OUT_PP)
    IOs[m].high()    

    for k in range(23):
        if k!=m:
            if IOs[k].value()==0:
                green_led.on()
                delay(100)
                green_led.off()
                delay(100)
            else:
                yellow_led.on()
                delay(100)
                yellow_led.off()
                delay(100)
                
    #reassign pin as input
    IOs[m].init(IOs[m].IN, IOs[m].PULL_DOWN)
  
    #red:   sinaliza um passo no main cycle
    red_led.on()
    delay(200)
    red_led.off()
 


#ended!!
blue_led.intensity(128) 







# --- Main Loop ---
while False:

    #start processing
    yellow_led.off()
    blue_led.on()



    #IOs setup & cycle
 
    #end processing
    #blue_led.off()
    blue_led.off()
    yellow_led.on()
    



